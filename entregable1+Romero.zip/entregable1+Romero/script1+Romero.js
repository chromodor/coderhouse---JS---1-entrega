// declaracion de variables, constantes y arrays
const PI = 3.14159;
let radius = 0;
let area = 0;
let circumference = 0;

// funcion para calcular el área de un circulo
function calculateArea(radius) {
  return PI * radius * radius;
}

// funcion para calcular la circunferencia de un circulo
function calculateCircumference(radius) {
  return 2 * PI * radius;
}

// funcion para mostrar los resultados
function displayResults(radius, area, circumference) {
  console.log(`Radio: ${radius}`);
  console.log(`Área: ${area}`);
  console.log(`Circunferencia: ${circumference}`);
  alert(`Resultados:\nÁrea: ${area}\nCircunferencia: ${circumference}`);
}

// funcion principal para interactuar con el usuario
function main() {
  radius = parseFloat(prompt("Ingrese el radio del círculo:"));
  if (isNaN(radius) || radius <= 0) {
    alert("Por favor, ingrese un número válido mayor que cero.");
    return;
  }

  area = calculateArea(radius);
  circumference = calculateCircumference(radius);

  displayResults(radius, area, circumference);
}

// llamada a la funcion principal
main();
